package assignment;

public class dog extends animal {
	boolean on = true;
	
	public dog(String name) {
		super(name);
		on = true;
	}
	
	public static String wang () {
		return "멍멍!";
	}
}
