package assignment;

public class cat extends animal {
	boolean on;
	
	public cat(String name) {
		super(name);
		on = true;
	}
	
	public static String meow () {
		return "야옹 ~";
	}
}
