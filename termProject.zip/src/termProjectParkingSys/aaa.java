/*
입고, 출고, 출력까지 다 함

package termProjectParkingSys;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.FlowLayout;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.SpringLayout;
import javax.swing.JTable;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import java.sql.ResultSet;
import java.sql.Statement;

public class GUI extends JFrame {
	private DBController DBC = new DBController();

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private DefaultTableModel tableModel; // DefaultTableModel 추가
	private JTable parkingTable;
	private JLabel Kinds1Num;
	private JLabel Kinds2Num;
	
	// Launch the application.
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI frame = new GUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// Create the frame.
	 
	public GUI() {
		ResultSet rs;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 763, 546);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(2, 3, 0, 0));
		
		JPanel showNum = new JPanel();
		contentPane.add(showNum);
		showNum.setLayout(new GridLayout(3, 1, 0, 0));
		
		JPanel gongPanel1 = new JPanel();
		showNum.add(gongPanel1);
		
		JLabel carNumText = new JLabel("");
		carNumText.setHorizontalAlignment(SwingConstants.CENTER);
		showNum.add(carNumText);
		
		JPanel kinds_panel = new JPanel();
		
		
		contentPane.add(kinds_panel);
		kinds_panel.setLayout(new GridLayout(4, 1, 0, 0));
		
		JLabel checkLabelKinds = new JLabel("Check Your Car Kinds:");
		checkLabelKinds.setVerticalAlignment(SwingConstants.BOTTOM);
		checkLabelKinds.setHorizontalAlignment(SwingConstants.CENTER);
		kinds_panel.add(checkLabelKinds);
		
		JPanel panel = new JPanel();
		kinds_panel.add(panel);
		
		DBC.startConnection();
		
		// radio 버튼 - kinds
		ButtonGroup group = new ButtonGroup();
		panel.setLayout(new GridLayout(2, 1, 0, 0));
		
		JPanel panel_1 = new JPanel();
		panel.add(panel_1);
		
		JRadioButton carKinds1 = new JRadioButton("승용차");
		panel_1.add(carKinds1);
		carKinds1.setSelected(true);
		
		group.add(carKinds1);
		
		JRadioButton carKinds2 = new JRadioButton("SUV");
		panel_1.add(carKinds2);
		group.add(carKinds2);
		
		JPanel panel_2 = new JPanel();
		panel.add(panel_2);
		panel_2.setLayout(new GridLayout(0, 1, 0, 0));
		
		JLabel showChkKinds = new JLabel("Now Parked:");
		showChkKinds.setVerticalAlignment(SwingConstants.BOTTOM);
		showChkKinds.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(showChkKinds);
		
		JPanel gongPanel2 = new JPanel();
		kinds_panel.add(gongPanel2);
		gongPanel2.setLayout(new GridLayout(2, 1, 0, 0));
		
		JPanel panel_3 = new JPanel();
		gongPanel2.add(panel_3);
		
		JLabel Kinds1Name = new JLabel("승용차: ");
		panel_3.add(Kinds1Name);
		
		Kinds1Num =new JLabel("");
		panel_3.add(Kinds1Num);
		
		JLabel gongbackT = new JLabel("        ");
		panel_3.add(gongbackT);
		
		JLabel Kinds2Name = new JLabel("SUV: ");
		panel_3.add(Kinds2Name);
		
		Kinds2Num = new JLabel("");
		panel_3.add(Kinds2Num);
		
		getKindsNum();
		
		
		// 입고
		JPanel carIn = new JPanel();
		gongPanel2.add(carIn);
		
		JButton btnCarIn = new JButton("입고");
		btnCarIn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() == 4) {
					try {
						int fullP = 0;
						for(int i=1; i<21; i++) {
							String carType = carKinds1.isSelected() ? "승용차" : "SUV";
							String sql = "SELECT * FROM pcar WHERE pid="+ i;
							String sql2 = "SELECT * FROM pcar WHERE carnum='"+ carNumText.getText() + "' and kinds='" + carType + "'";
							
							if (DBC.outDB(sql2)) {
								fullP = 0;
								showErrorDialog("Error: Already registered vehicle number.");
								break;
							}
							else if(!DBC.outDB(sql) && !DBC.outDB(sql2)) {
								fullP = 0;
								if (DBC.outNum("SUV") >= 5 && carType == "SUV") // suv >= 5인데, suv가 또 들어오려 할 경우 쳐냄.
									showErrorDialog("Error: No more parking space. (SUV)");
								else { // suv 경우가 아닐경우, 들어옴.
									sql = "INSERT INTO pcar VALUES("+ i +", '"+ carNumText.getText() +"', '"+ carType +"')";
									System.out.println(sql);
									
									DBC.ExeQry(sql);
								}
								
								getKindsNum();
								break;
							}
							else {
								fullP = 1;
							}
						}
						if (fullP == 1) {
							showErrorDialog("Error: No more parking space.");
						}
					} catch (Exception er) {
						er.printStackTrace();
					}
				}
				else { // 올바르지 않는 값일 경우
					showErrorDialog("Error: The input is not valid.");
				}
				
				carNumText.setText("");
			}
		});
		carIn.add(btnCarIn);
		
		JPanel gongPanel2_1 = new JPanel();
		kinds_panel.add(gongPanel2_1);
		gongPanel2_1.setLayout(new GridLayout(2, 1, 0, 0));
		
		
		// 출고
		JPanel carOut = new JPanel();
		gongPanel2_1.add(carOut);
		
		JButton btnCarOut = new JButton("출고");
		carOut.add(btnCarOut);
		btnCarOut.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() == 4) {
					String carType = carKinds1.isSelected() ? "승용차" : "SUV";
					
					String sql = "SELECT * FROM pcar WHERE carnum='"+ carNumText.getText() + "' and kinds='" + carType + "'";
					if(DBC.outDB(sql)) {
						sql = "DELETE FROM pcar WHERE carnum='"+ carNumText.getText() + "' and kinds='" + carType + "'";
						DBC.ExeQry(sql);
						getKindsNum();
					}
				}
				else {
					showErrorDialog("Error: The input is not valid.");
				}
				
				carNumText.setText("");
			}
		});
		
		
		// 주차장 확인
		JPanel carShow = new JPanel();
		gongPanel2_1.add(carShow);
		
		JButton btnCarShow = new JButton("주차장 확인");
		carShow.add(btnCarShow);
		btnCarShow.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {


	            tableModel.setRowCount(0);
	            tableModel.setColumnCount(0);
	            tableModel.addColumn("Index");
	            tableModel.addColumn("차량번호 (종류)");
		        
		        // 주차장 현황 데이터 로드
		        loadParkingData();
			}
		});
		
		
		// num 버튼 - num_panel 
		JPanel num_panel = new JPanel();
		contentPane.add(num_panel);
		num_panel.setLayout(new GridLayout(4, 3, 0, 0));
		
		JButton btn1 = new JButton("1");
		btn1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "1");
				}
			}
		});
		num_panel.add(btn1);
		
		JButton btn2 = new JButton("2");
		btn2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "2");
				}
			}
		});
		num_panel.add(btn2);
		
		JButton btn3 = new JButton("3");
		btn3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "3");
				}
			}
		});
		num_panel.add(btn3);
		
		JButton btn4 = new JButton("4");
		btn4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "4");
				}
			}
		});
		num_panel.add(btn4);
		
		JButton btn5 = new JButton("5");
		btn5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "5");
				}
			}
		});
		num_panel.add(btn5);
		
		JButton btn6 = new JButton("6");
		btn6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "6");
				}
			}
		});
		num_panel.add(btn6);
		
		JButton btn7 = new JButton("7");
		btn7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "7");
				}
			}
		});
		num_panel.add(btn7);
		
		JButton btn8 = new JButton("8");
		btn8.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "8");
				}
			}
		});
		num_panel.add(btn8);
		
		JButton btn9 = new JButton("9");
		btn9.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "9");
				}
			}
		});
		num_panel.add(btn9);
		
		JButton btnDelete = new JButton("DEL");
		btnDelete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) { 
				if (carNumText.getText().length() == 0) {
				}
				else {
					String s = carNumText.getText().substring(0, carNumText.getText().length() - 1);
					carNumText.setText(s);
				}
			}
		});
		num_panel.add(btnDelete);
		
		JButton btn0 = new JButton("0");
		btn0.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "0");
				}
			}
		});
		num_panel.add(btn0);
		
		JButton btnAllDelete = new JButton("A_DEL");
		btnAllDelete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				carNumText.setText("");
			}
		});
		num_panel.add(btnAllDelete);
		
		JPanel chkAction = new JPanel();
		contentPane.add(chkAction);
		chkAction.setLayout(new GridLayout(1, 1, 0, 0));
		
		
		// 주차장 현황 상태 출력 테이블
//		table = new JTable();
//		chkAction.add(table);

        tableModel = new DefaultTableModel();

        parkingTable = new JTable(tableModel) {
        	@Override
        	public boolean isCellEditable(int row, int column) {
        		return false;
        	}
        };
        
		JScrollPane scrollPane = new JScrollPane(parkingTable);
		chkAction.add(scrollPane);      
		
	}
	
	private static void showErrorDialog(String message) {
        // JOptionPane을 사용하여 에러 다이얼로그 표시
        JOptionPane.showMessageDialog(null, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
	
	private void loadParkingData() {       
        
        for (int i = 1; i <= 20; i++) {
            String sql = "SELECT * FROM pcar WHERE pid=" + i;
            
            if (!DBC.outDB(sql)) {
            	tableModel.addRow(new Object[]{i, "-"});
            } else {
            	// 주차 번호 및 차량 정보 조회
                String parkInfo = DBC.showParking(i);
                // 주차장 테이블에 추가
                tableModel.addRow(new Object[]{i, parkInfo});
            }   
        }
    }
	
	private void getKindsNum() {
		Kinds1Num.setText(""+ DBC.outNum("승용차"));

		Kinds2Num.setText(""+ DBC.outNum("SUV"));
	}
}
*/