package termProjectParkingSys;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import javax.swing.JTable;
import java.awt.Component;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import com.jgoodies.forms.layout.FormSpecs;
import javax.swing.SpringLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Dimension;
import javax.swing.JTextPane;


public class parkingShow extends JFrame {

	private DBController DBC = new DBController();
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField dd;
	private JPanel showInfo;
	private JPanel panel;
	private JPanel panel_1;
	private JTextField index_1;
	private JTextField p1;
	private JTextField index_2;
	private JTextField p2;
	private JTextField index_3;
	private JTextField p3;
	private JTextField index_4;
	private JTextField p4;
	private JTextField index_5;
	private JTextField p5;
	private JTextField index_6;
	private JTextField p6;
	private JTextField index_7;
	private JTextField p7;
	private JTextField index_8;
	private JTextField p8;
	private JTextField index_9;
	private JTextField p9;
	private JTextField index_10;
	private JTextField p10;
	private JTextField index_11;
	private JTextField p11;
	private JTextField index_12;
	private JTextField p12;
	private JTextField index_13;
	private JTextField p13;
	private JTextField index_14;
	private JTextField p14;
	private JTextField index_15;
	private JTextField p15;
	private JTextField index_16;
	private JTextField p16;
	private JTextField index_17;
	private JTextField p17;
	private JTextField index_18;
	private JTextField p18;
	private JTextField index_19;
	private JTextField p19;
	private JTextField index_20;
	private JTextField p20;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					parkingShow frame = new parkingShow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public parkingShow() {
		DBC.startConnection();
		
		getContentPane().setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 585, 402);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		SpringLayout sl_contentPane = new SpringLayout();
		contentPane.setLayout(sl_contentPane);
		
		JPanel head = new JPanel();
		sl_contentPane.putConstraint(SpringLayout.NORTH, head, 10, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, head, 48, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, head, 53, SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, head, 514, SpringLayout.WEST, contentPane);
		contentPane.add(head);
		head.setLayout(new GridLayout(0, 1, 0, 0));
		
		dd = new JTextField();
		dd.setHorizontalAlignment(SwingConstants.CENTER);
		dd.setEnabled(false);
		dd.setText("The current parking situation.");
		head.add(dd);
		dd.setColumns(10);
		
		showInfo = new JPanel();
		sl_contentPane.putConstraint(SpringLayout.NORTH, showInfo, 8, SpringLayout.SOUTH, head);
		sl_contentPane.putConstraint(SpringLayout.WEST, showInfo, 10, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, showInfo, 294, SpringLayout.SOUTH, head);
		sl_contentPane.putConstraint(SpringLayout.EAST, showInfo, 553, SpringLayout.WEST, contentPane);
		contentPane.add(showInfo);
		showInfo.setLayout(new GridLayout(1, 2, 10, 0));
		
		panel = new JPanel();
		showInfo.add(panel);
		panel.setLayout(new FormLayout(new ColumnSpec[] {
				ColumnSpec.decode("133px"),
				ColumnSpec.decode("133px"),},
			new RowSpec[] {
				FormSpecs.LABEL_COMPONENT_GAP_ROWSPEC,
				RowSpec.decode("28px"),
				RowSpec.decode("28px"),
				RowSpec.decode("28px"),
				RowSpec.decode("28px"),
				RowSpec.decode("28px"),
				RowSpec.decode("28px"),
				RowSpec.decode("28px"),
				RowSpec.decode("28px"),
				RowSpec.decode("28px"),
				RowSpec.decode("28px"),}));
		
		index_1 = new JTextField();
		index_1.setHorizontalAlignment(SwingConstants.CENTER);
		index_1.setEnabled(false);
		index_1.setText("1");
		panel.add(index_1, "1, 2, center, fill");
		index_1.setColumns(10);
		
		p1 = new JTextField();
		p1.setHorizontalAlignment(SwingConstants.LEFT);
		p1.setEnabled(false);
		panel.add(p1, "2, 2, fill, fill");
		p1.setColumns(10);
		p1.setText(DBC.showParking(index_1.getText()));
		
		index_2 = new JTextField();
		index_2.setHorizontalAlignment(SwingConstants.CENTER);
		index_2.setEnabled(false);
		index_2.setText("2");
		index_2.setColumns(10);
		panel.add(index_2, "1, 3, center, fill");
		
		p2 = new JTextField();
		p2.setHorizontalAlignment(SwingConstants.LEFT);
		p2.setEnabled(false);
		p2.setColumns(10);
		panel.add(p2, "2, 3, fill, fill");
		
		index_3 = new JTextField();
		index_3.setHorizontalAlignment(SwingConstants.CENTER);
		index_3.setEnabled(false);
		index_3.setText("3");
		index_3.setColumns(10);
		panel.add(index_3, "1, 4, center, fill");
		
		p3 = new JTextField();
		p3.setHorizontalAlignment(SwingConstants.LEFT);
		p3.setEnabled(false);
		p3.setColumns(10);
		panel.add(p3, "2, 4, fill, fill");
		
		index_4 = new JTextField();
		index_4.setHorizontalAlignment(SwingConstants.CENTER);
		index_4.setEnabled(false);
		index_4.setText("4");
		index_4.setColumns(10);
		panel.add(index_4, "1, 5, center, fill");
		
		p4 = new JTextField();
		p4.setHorizontalAlignment(SwingConstants.LEFT);
		p4.setEnabled(false);
		p4.setColumns(10);
		panel.add(p4, "2, 5, fill, fill");
		
		index_5 = new JTextField();
		index_5.setHorizontalAlignment(SwingConstants.CENTER);
		index_5.setEnabled(false);
		index_5.setText("5");
		index_5.setColumns(10);
		panel.add(index_5, "1, 6, center, fill");
		
		p5 = new JTextField();
		p5.setHorizontalAlignment(SwingConstants.LEFT);
		p5.setEnabled(false);
		p5.setColumns(10);
		panel.add(p5, "2, 6, fill, fill");
		
		index_6 = new JTextField();
		index_6.setHorizontalAlignment(SwingConstants.CENTER);
		index_6.setEnabled(false);
		index_6.setText("6");
		index_6.setColumns(10);
		panel.add(index_6, "1, 7, center, fill");
		
		p6 = new JTextField();
		p6.setHorizontalAlignment(SwingConstants.LEFT);
		p6.setEnabled(false);
		p6.setColumns(10);
		panel.add(p6, "2, 7, fill, fill");
		
		index_7 = new JTextField();
		index_7.setHorizontalAlignment(SwingConstants.CENTER);
		index_7.setEnabled(false);
		index_7.setText("7");
		index_7.setColumns(10);
		panel.add(index_7, "1, 8, center, fill");
		
		p7 = new JTextField();
		p7.setHorizontalAlignment(SwingConstants.LEFT);
		p7.setEnabled(false);
		p7.setColumns(10);
		panel.add(p7, "2, 8, fill, fill");
		
		index_8 = new JTextField();
		index_8.setHorizontalAlignment(SwingConstants.CENTER);
		index_8.setEnabled(false);
		index_8.setText("8");
		index_8.setColumns(10);
		panel.add(index_8, "1, 9, center, fill");
		
		p8 = new JTextField();
		p8.setHorizontalAlignment(SwingConstants.LEFT);
		p8.setEnabled(false);
		p8.setColumns(10);
		panel.add(p8, "2, 9, fill, fill");
		
		index_9 = new JTextField();
		index_9.setHorizontalAlignment(SwingConstants.CENTER);
		index_9.setEnabled(false);
		index_9.setText("9");
		index_9.setColumns(10);
		panel.add(index_9, "1, 10, center, fill");
		
		p9 = new JTextField();
		p9.setHorizontalAlignment(SwingConstants.LEFT);
		p9.setEnabled(false);
		p9.setColumns(10);
		panel.add(p9, "2, 10, fill, fill");
		
		index_10 = new JTextField();
		index_10.setHorizontalAlignment(SwingConstants.CENTER);
		index_10.setEnabled(false);
		index_10.setText("10");
		index_10.setColumns(10);
		panel.add(index_10, "1, 11, center, fill");
		
		p10 = new JTextField();
		p10.setHorizontalAlignment(SwingConstants.LEFT);
		p10.setEnabled(false);
		p10.setColumns(10);
		panel.add(p10, "2, 11, fill, fill");
		
		panel_1 = new JPanel();
		showInfo.add(panel_1);
		panel_1.setLayout(new FormLayout(new ColumnSpec[] {
				ColumnSpec.decode("133px"),
				ColumnSpec.decode("133px"),},
			new RowSpec[] {
				FormSpecs.LABEL_COMPONENT_GAP_ROWSPEC,
				RowSpec.decode("28px"),
				RowSpec.decode("28px"),
				RowSpec.decode("28px"),
				RowSpec.decode("28px"),
				RowSpec.decode("28px"),
				RowSpec.decode("28px"),
				RowSpec.decode("28px"),
				RowSpec.decode("28px"),
				RowSpec.decode("28px"),
				RowSpec.decode("28px"),}));
		
		index_11 = new JTextField();
		index_11.setHorizontalAlignment(SwingConstants.CENTER);
		index_11.setEnabled(false);
		index_11.setText("11");
		index_11.setColumns(10);
		panel_1.add(index_11, "1, 2, center, fill");
		
		p11 = new JTextField();
		p11.setHorizontalAlignment(SwingConstants.LEFT);
		p11.setEnabled(false);
		p11.setColumns(10);
		panel_1.add(p11, "2, 2, fill, fill");
		
		index_12 = new JTextField();
		index_12.setHorizontalAlignment(SwingConstants.CENTER);
		index_12.setEnabled(false);
		index_12.setText("12");
		index_12.setColumns(10);
		panel_1.add(index_12, "1, 3, center, fill");
		
		p12 = new JTextField();
		p12.setHorizontalAlignment(SwingConstants.LEFT);
		p12.setEnabled(false);
		p12.setColumns(10);
		panel_1.add(p12, "2, 3, fill, fill");
		
		index_13 = new JTextField();
		index_13.setHorizontalAlignment(SwingConstants.CENTER);
		index_13.setEnabled(false);
		index_13.setText("13");
		index_13.setColumns(10);
		panel_1.add(index_13, "1, 4, center, fill");
		
		p13 = new JTextField();
		p13.setHorizontalAlignment(SwingConstants.LEFT);
		p13.setEnabled(false);
		p13.setColumns(10);
		panel_1.add(p13, "2, 4, fill, fill");
		
		index_14 = new JTextField();
		index_14.setHorizontalAlignment(SwingConstants.CENTER);
		index_14.setEnabled(false);
		index_14.setText("14");
		index_14.setColumns(10);
		panel_1.add(index_14, "1, 5, center, fill");
		
		p14 = new JTextField();
		p14.setHorizontalAlignment(SwingConstants.LEFT);
		p14.setEnabled(false);
		p14.setColumns(10);
		panel_1.add(p14, "2, 5, fill, fill");
		
		index_15 = new JTextField();
		index_15.setHorizontalAlignment(SwingConstants.CENTER);
		index_15.setEnabled(false);
		index_15.setText("15");
		index_15.setColumns(10);
		panel_1.add(index_15, "1, 6, center, fill");
		
		p15 = new JTextField();
		p15.setHorizontalAlignment(SwingConstants.LEFT);
		p15.setEnabled(false);
		p15.setColumns(10);
		panel_1.add(p15, "2, 6, fill, fill");
		
		index_16 = new JTextField();
		index_16.setHorizontalAlignment(SwingConstants.CENTER);
		index_16.setEnabled(false);
		index_16.setText("16");
		index_16.setColumns(10);
		panel_1.add(index_16, "1, 7, center, fill");
		
		p16 = new JTextField();
		p16.setHorizontalAlignment(SwingConstants.LEFT);
		p16.setEnabled(false);
		p16.setColumns(10);
		panel_1.add(p16, "2, 7, fill, fill");
		
		index_17 = new JTextField();
		index_17.setHorizontalAlignment(SwingConstants.CENTER);
		index_17.setEnabled(false);
		index_17.setText("17");
		index_17.setColumns(10);
		panel_1.add(index_17, "1, 8, center, fill");
		
		p17 = new JTextField();
		p17.setHorizontalAlignment(SwingConstants.LEFT);
		p17.setEnabled(false);
		p17.setColumns(10);
		panel_1.add(p17, "2, 8, fill, fill");
		
		index_18 = new JTextField();
		index_18.setHorizontalAlignment(SwingConstants.CENTER);
		index_18.setEnabled(false);
		index_18.setText("18");
		index_18.setColumns(10);
		panel_1.add(index_18, "1, 9, center, fill");
		
		p18 = new JTextField();
		p18.setHorizontalAlignment(SwingConstants.LEFT);
		p18.setEnabled(false);
		p18.setColumns(10);
		panel_1.add(p18, "2, 9, fill, fill");
		
		index_19 = new JTextField();
		index_19.setHorizontalAlignment(SwingConstants.CENTER);
		index_19.setEnabled(false);
		index_19.setText("19");
		index_19.setColumns(10);
		panel_1.add(index_19, "1, 10, center, fill");
		
		p19 = new JTextField();
		p19.setHorizontalAlignment(SwingConstants.LEFT);
		p19.setEnabled(false);
		p19.setColumns(10);
		panel_1.add(p19, "2, 10, fill, fill");
		
		index_20 = new JTextField();
		index_20.setHorizontalAlignment(SwingConstants.CENTER);
		index_20.setEnabled(false);
		index_20.setText("20");
		index_20.setColumns(10);
		panel_1.add(index_20, "1, 11, center, fill");
		
		p20 = new JTextField();
		p20.setHorizontalAlignment(SwingConstants.LEFT);
		p20.setEnabled(false);
		p20.setColumns(10);
		panel_1.add(p20, "2, 11, fill, fill");
	}
}
