package termProjectParkingSys;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.FlowLayout;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GUI extends JFrame {
	// private DBController DBC = new DBController();

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI frame = new GUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GUI() {
		// DBC.startConnection();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(2, 2, 10, 0));
		
		JPanel showNum = new JPanel();
		contentPane.add(showNum);
		showNum.setLayout(new GridLayout(3, 1, 0, 0));
		
		JPanel gongPanel1 = new JPanel();
		showNum.add(gongPanel1);
		
		JLabel carNumText = new JLabel("");
		carNumText.setHorizontalAlignment(SwingConstants.CENTER);
		showNum.add(carNumText);
		
		JPanel kinds_panel = new JPanel();
		contentPane.add(kinds_panel);
		kinds_panel.setLayout(new GridLayout(4, 1, 0, 0));
		
		JPanel gongPanel2 = new JPanel();
		kinds_panel.add(gongPanel2);
		
		JLabel checkLabelKinds = new JLabel("Check Your Car Kinds:");
		checkLabelKinds.setHorizontalAlignment(SwingConstants.CENTER);
		kinds_panel.add(checkLabelKinds);
		
		JPanel panel = new JPanel();
		kinds_panel.add(panel);
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		// radio 버튼 - kinds
		
		ButtonGroup group = new ButtonGroup();
		
		JRadioButton carKinds1 = new JRadioButton("승용차");
		carKinds1.setSelected(true);
		panel.add(carKinds1);
		
		JRadioButton carKinds2 = new JRadioButton("SUV");
		panel.add(carKinds2);
		
		group.add(carKinds1);
		group.add(carKinds2);
		
		// num 버튼 - num_panel 
		
		JPanel num_panel = new JPanel();
		contentPane.add(num_panel);
		num_panel.setLayout(new GridLayout(4, 3, 0, 0));
		
		JButton btn1 = new JButton("1");
		btn1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				carNumText.setText(carNumText.getText() + "1");
			}
		});
		num_panel.add(btn1);
		
		JButton btn2 = new JButton("2");
		num_panel.add(btn2);
		
		JButton btn3 = new JButton("3");
		num_panel.add(btn3);
		
		JButton btn4 = new JButton("4");
		num_panel.add(btn4);
		
		JButton btn5 = new JButton("5");
		num_panel.add(btn5);
		
		JButton btn6 = new JButton("6");
		num_panel.add(btn6);
		
		JButton btn7 = new JButton("7");
		num_panel.add(btn7);
		
		JButton btn8 = new JButton("8");
		num_panel.add(btn8);
		
		JButton btn9 = new JButton("9");
		num_panel.add(btn9);
		
		JButton btnDelete = new JButton("DEL");
		num_panel.add(btnDelete);
		
		JButton btn0 = new JButton("0");
		num_panel.add(btn0);
		
		JButton btnAllDelete = new JButton("A_DEL");
		num_panel.add(btnAllDelete);
		
		JPanel chkAction = new JPanel();
		contentPane.add(chkAction);
		chkAction.setLayout(new GridLayout(3, 1, 0, 0));
		
		JPanel carIn = new JPanel();
		chkAction.add(carIn);
		
		JButton btnCarIn = new JButton("입고");
		carIn.add(btnCarIn);
		
		JPanel carOut = new JPanel();
		chkAction.add(carOut);
		
		JButton btnCarOut = new JButton("출고");
		carOut.add(btnCarOut);
		
		JPanel carShow = new JPanel();
		chkAction.add(carShow);
		
		JButton btnCarShow = new JButton("주차장 확인");
		carShow.add(btnCarShow);
		
		
	}

}
