package termProjectParkingSys;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class GUI extends JFrame {
	private DBController DBC;

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI frame = new GUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(2, 2, 10, 0));
		
		JPanel showNum = new JPanel();
		contentPane.add(showNum);
		showNum.setLayout(new GridLayout(3, 1, 0, 0));
		
		JPanel panel_1 = new JPanel();
		showNum.add(panel_1);
		
		JLabel lblNewLabel = new JLabel("Sample");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		showNum.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		contentPane.add(panel);
		
		JPanel num_panel = new JPanel();
		contentPane.add(num_panel);
		num_panel.setLayout(new GridLayout(4, 3, 0, 0));
		
		JButton btn1 = new JButton("1");
		num_panel.add(btn1);
		
		JButton btn2 = new JButton("2");
		num_panel.add(btn2);
		
		JButton btn3 = new JButton("3");
		num_panel.add(btn3);
		
		JButton btn4 = new JButton("4");
		num_panel.add(btn4);
		
		JButton btn5 = new JButton("5");
		num_panel.add(btn5);
		
		JButton btn6 = new JButton("6");
		num_panel.add(btn6);
		
		JButton btn7 = new JButton("7");
		num_panel.add(btn7);
		
		JButton btn8 = new JButton("8");
		num_panel.add(btn8);
		
		JButton btn9 = new JButton("9");
		num_panel.add(btn9);
		
		JButton btnDelete = new JButton("DEL");
		num_panel.add(btnDelete);
		
		JButton btn0 = new JButton("0");
		num_panel.add(btn0);
		
		JButton btnAllDelete = new JButton("A_DEL");
		num_panel.add(btnAllDelete);
		
		JPanel panel_3 = new JPanel();
		contentPane.add(panel_3);
		panel_3.setLayout(new GridLayout(1, 0, 0, 0));
		
		DBC = new DBController();
		DBC.startConnection();
	}

}
