package termProjectParkingSys;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.FlowLayout;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.table.TableColumnModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.SpringLayout;
import javax.swing.JTable;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.Color;
import java.awt.Font;


public class GUI extends JFrame {
	private DBController DBC = new DBController();

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private DefaultTableModel tableModel; // DefaultTableModel 추가
	private JTable parkingTable;
	private JLabel Kinds1Num;
	private JLabel Kinds2Num;
	
	// Launch the application.
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI frame = new GUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// Create the frame.
	 
	public GUI() {
		setBackground(new Color(255, 255, 255));
		ResultSet rs;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 763, 546);
		setTitle("Parking System");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(2, 3, 0, 0));
		
		JPanel showNum = new JPanel();
		showNum.setBackground(new Color(255, 255, 255));
		contentPane.add(showNum);
		showNum.setLayout(new GridLayout(3, 1, 0, 0));
		
		JPanel gongPanel1 = new JPanel();
		gongPanel1.setBackground(new Color(255, 255, 255));
		showNum.add(gongPanel1);
		gongPanel1.setLayout(new GridLayout(0, 1, 0, 0));
		
		JLabel lblNewLabel = new JLabel("Input your car number (4):");
		lblNewLabel.setFont(new Font("돋움", Font.PLAIN, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setVerticalAlignment(SwingConstants.BOTTOM);
		gongPanel1.add(lblNewLabel);
		
		JLabel carNumText = new JLabel("");
		carNumText.setFont(new Font("돋움", Font.PLAIN, 65));
		carNumText.setBackground(new Color(255, 255, 255));
		carNumText.setHorizontalAlignment(SwingConstants.CENTER);
		showNum.add(carNumText);
		
		JPanel kinds_panel = new JPanel();
		kinds_panel.setBackground(new Color(255, 255, 255));
		
		
		contentPane.add(kinds_panel);
		kinds_panel.setLayout(new GridLayout(4, 1, 0, 0));
		
		JLabel checkLabelKinds = new JLabel("Check Your Car Kinds:");
		checkLabelKinds.setFont(new Font("돋움", Font.PLAIN, 20));
		checkLabelKinds.setBackground(new Color(255, 255, 255));
		checkLabelKinds.setVerticalAlignment(SwingConstants.BOTTOM);
		checkLabelKinds.setHorizontalAlignment(SwingConstants.CENTER);
		kinds_panel.add(checkLabelKinds);
		
		JPanel panel = new JPanel();
		kinds_panel.add(panel);
		
		DBC.startConnection();
		
		// radio 버튼 - kinds
		ButtonGroup group = new ButtonGroup();
		panel.setLayout(new GridLayout(2, 1, 0, 0));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		panel.add(panel_1);
		
		JRadioButton carKinds1 = new JRadioButton("승용차");
		carKinds1.setBackground(new Color(255, 255, 255));
		carKinds1.setFont(new Font("돋움", Font.PLAIN, 15));
		panel_1.add(carKinds1);
		carKinds1.setSelected(true);
		
		group.add(carKinds1);
		
		JRadioButton carKinds2 = new JRadioButton("SUV");
		carKinds2.setBackground(new Color(255, 255, 255));
		carKinds2.setFont(new Font("돋움", Font.PLAIN, 15));
		panel_1.add(carKinds2);
		group.add(carKinds2);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		panel.add(panel_2);
		panel_2.setLayout(new GridLayout(0, 1, 0, 0));
		
		JLabel showChkKinds = new JLabel("Now Parked:");
		showChkKinds.setFont(new Font("돋움", Font.PLAIN, 20));
		showChkKinds.setBackground(new Color(255, 255, 255));
		showChkKinds.setVerticalAlignment(SwingConstants.BOTTOM);
		showChkKinds.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(showChkKinds);
		
		JPanel gongPanel2 = new JPanel();
		kinds_panel.add(gongPanel2);
		gongPanel2.setLayout(new GridLayout(2, 1, 0, 0));
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(255, 255, 255));
		gongPanel2.add(panel_3);
		
		JLabel Kinds1Name = new JLabel("승용차: ");
		Kinds1Name.setFont(new Font("돋움", Font.PLAIN, 15));
		panel_3.add(Kinds1Name);
		
		Kinds1Num =new JLabel("");
		Kinds1Num.setFont(new Font("돋움", Font.PLAIN, 15));
		panel_3.add(Kinds1Num);
		
		JLabel gongbackT = new JLabel("        ");
		panel_3.add(gongbackT);
		
		JLabel Kinds2Name = new JLabel("SUV: ");
		Kinds2Name.setFont(new Font("돋움", Font.PLAIN, 15));
		panel_3.add(Kinds2Name);
		
		Kinds2Num = new JLabel("");
		Kinds2Num.setFont(new Font("돋움", Font.PLAIN, 15));
		panel_3.add(Kinds2Num);
		
		getKindsNum();

		
		// 입고
		JPanel sys1 = new JPanel();
		sys1.setBackground(new Color(255, 255, 255));
		gongPanel2.add(sys1);
		
		JButton btnCarIn = new JButton("입고");
		btnCarIn.setFont(new Font("돋움", Font.BOLD, 14));
		btnCarIn.setForeground(new Color(255, 255, 255));
		btnCarIn.setBackground(new Color(26, 55, 87));
		btnCarIn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() == 4) {
					try {						
						String carType = carKinds1.isSelected() ? "승용차" : "SUV";
						String sql = "SELECT * FROM pcar WHERE carnum='"+ carNumText.getText() + "'";
						String sql2 = "SELECT * FROM pcar WHERE pid=";
						
						if (DBC.outDB(sql)) { // 이미 있는 자동차 번호인가?
							showErrorDialog("Error: Already registered vehicle number.");
						}
						else if (carType.equals("SUV")) { // SUV
							methodSUVIn(sql2, carNumText);
							// 15 ~ 20 주차장을 확인하고 그 부분에서만 집어넣기
						}
						else { // 승용차 
							methodCarIn(sql2, carNumText);
						}
						
						getKindsNum();
					} catch (Exception er) {
						er.printStackTrace();
					}
				}
				else { // 올바르지 않는 값일 경우
					showErrorDialog("Error: The input is not valid.");
				}
				
				carNumText.setText("");
			}
		});
		sys1.add(btnCarIn);
		
		JPanel gongPanel2_1 = new JPanel();
		gongPanel2_1.setBackground(new Color(255, 255, 255));
		kinds_panel.add(gongPanel2_1);
		gongPanel2_1.setLayout(new GridLayout(2, 1, 0, 0));
		
		
		// 주차장 확인
		JPanel sys2 = new JPanel();
		sys2.setBackground(new Color(255, 255, 255));
		gongPanel2_1.add(sys2);
		
		
		// 출고
		JButton btnCarOut = new JButton("출고");
		sys2.add(btnCarOut);
		btnCarOut.setFont(new Font("돋움", Font.BOLD, 14));
		btnCarOut.setForeground(new Color(255, 255, 255));
		btnCarOut.setBackground(new Color(26, 55, 87));
		
		btnCarOut.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() == 4) {
					
					String sql = "SELECT * FROM pcar WHERE carnum='"+ carNumText.getText() + "'";
					if(DBC.outDB(sql)) {
						if (showOptionDialog("출고하시겠습니까?", "CarOut")==0) {
							sql = "DELETE FROM pcar WHERE carnum='"+ carNumText.getText() + "'";
							DBC.ExeQry(sql);
							getKindsNum();
							loadParkingData();
						}
					}
					else {
						showErrorDialog("Error: The vehicle is not parked.");
					}
				}
				else {
					showErrorDialog("Error: The input is not valid.");
				}
				
				carNumText.setText("");
			}
		});
		
		
		
		// num 버튼 - num_panel 
		JPanel num_panel = new JPanel();
		contentPane.add(num_panel);
		num_panel.setLayout(new GridLayout(4, 3, 0, 0));
		
		JButton btn1 = new JButton("1");
		btn1.setFont(new Font("돋움", Font.PLAIN, 22));
		btn1.setBackground(new Color(255, 255, 255));
		btn1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "1");
				}
			}
		});
		num_panel.add(btn1);
		
		JButton btn2 = new JButton("2");
		btn2.setFont(new Font("돋움", Font.PLAIN, 22));
		btn2.setBackground(new Color(255, 255, 255));
		btn2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "2");
				}
			}
		});
		num_panel.add(btn2);
		
		JButton btn3 = new JButton("3");
		btn3.setFont(new Font("돋움", Font.PLAIN, 22));
		btn3.setBackground(new Color(255, 255, 255));
		btn3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "3");
				}
			}
		});
		num_panel.add(btn3);
		
		JButton btn4 = new JButton("4");
		btn4.setFont(new Font("돋움", Font.PLAIN, 22));
		btn4.setBackground(new Color(255, 255, 255));
		btn4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "4");
				}
			}
		});
		num_panel.add(btn4);
		
		JButton btn5 = new JButton("5");
		btn5.setFont(new Font("돋움", Font.PLAIN, 22));
		btn5.setBackground(new Color(255, 255, 255));
		btn5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "5");
				}
			}
		});
		num_panel.add(btn5);
		
		JButton btn6 = new JButton("6");
		btn6.setFont(new Font("돋움", Font.PLAIN, 22));
		btn6.setBackground(new Color(255, 255, 255));
		btn6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "6");
				}
			}
		});
		num_panel.add(btn6);
		
		JButton btn7 = new JButton("7");
		btn7.setFont(new Font("돋움", Font.PLAIN, 22));
		btn7.setBackground(new Color(255, 255, 255));
		btn7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "7");
				}
			}
		});
		num_panel.add(btn7);
		
		JButton btn8 = new JButton("8");
		btn8.setFont(new Font("돋움", Font.PLAIN, 22));
		btn8.setBackground(new Color(255, 255, 255));
		btn8.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "8");
				}
			}
		});
		num_panel.add(btn8);
		
		JButton btn9 = new JButton("9");
		btn9.setFont(new Font("돋움", Font.PLAIN, 22));
		btn9.setBackground(new Color(255, 255, 255));
		btn9.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "9");
				}
			}
		});
		num_panel.add(btn9);
		
		JButton btnDelete = new JButton("DEL");
		btnDelete.setFont(new Font("돋움", Font.PLAIN, 20));
		btnDelete.setBackground(new Color(255, 255, 255));
		btnDelete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) { 
				if (carNumText.getText().length() == 0) {
				}
				else {
					String s = carNumText.getText().substring(0, carNumText.getText().length() - 1);
					carNumText.setText(s);
				}
			}
		});
		num_panel.add(btnDelete);
		
		JButton btn0 = new JButton("0");
		btn0.setFont(new Font("돋움", Font.PLAIN, 22));
		btn0.setBackground(new Color(255, 255, 255));
		btn0.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (carNumText.getText().length() < 4) {
					carNumText.setText(carNumText.getText() + "0");
				}
			}
		});
		num_panel.add(btn0);
		
		JButton btnAllDelete = new JButton("A_DEL");
		btnAllDelete.setFont(new Font("돋움", Font.PLAIN, 20));
		btnAllDelete.setBackground(new Color(255, 255, 255));
		btnAllDelete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				carNumText.setText("");
			}
		});
		num_panel.add(btnAllDelete);
		
		JPanel chkAction = new JPanel();
		contentPane.add(chkAction);
		chkAction.setLayout(new GridLayout(1, 1, 0, 0));
		
		
		// 주차장 현황 상태 출력 테이블

        tableModel = new DefaultTableModel();

        parkingTable = new JTable(tableModel) {
        	@Override
        	public boolean isCellEditable(int row, int column) {
        		return false;
        	}
        };
        
		JScrollPane scrollPane = new JScrollPane(parkingTable);
		chkAction.add(scrollPane);   
		

        loadParkingData();
	}
	private static int showOptionDialog(String message, String sys) {
		int ans = JOptionPane.showConfirmDialog(null, message, sys, JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE);
		return ans;
	}
	
	private static void showErrorDialog(String message) {
        // JOptionPane을 사용하여 에러 다이얼로그 표시
        JOptionPane.showMessageDialog(null, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
	
	private void loadParkingData() {       
		TableColumnModel columnModel = parkingTable.getColumnModel();
		
		tableModel.setRowCount(0);
        tableModel.setColumnCount(0);
        tableModel.addColumn("Index");
        tableModel.addColumn("차량번호 (종류)");
        
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        
        for (int i = 1; i <= 20; i++) {
            String sql = "SELECT * FROM pcar WHERE pid=" + i;
            
            if (!DBC.outDB(sql)) {
            	tableModel.addRow(new Object[]{i, "-"});
            } else {
                String parkInfo = DBC.showParking(i); // 주차 번호 및 차량 정보 조회
                tableModel.addRow(new Object[]{i, parkInfo}); // 주차장 테이블에 추가
            }   
        }
        
        for (int i = 0; i < tableModel.getColumnCount(); i++) {
            parkingTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
        
        columnModel.getColumn(0).setPreferredWidth(5);
        parkingTable.setRowHeight(30);
    }
	
	private void getKindsNum() {
		Kinds1Num.setText(""+ DBC.outNum("<= 15") + "/15");
		Kinds2Num.setText(""+ DBC.outNum(">= 16") + "/5");
	}
	
	private void methodCarIn(String sql, JLabel carNumText) {
		for(int i=1; i<21; i++) {
			String sql2 = "select count(*) as num from pcar where pid<=20"; 
			
			if (DBC.outNumber(sql2) == 20) { // 꽉 찼을 경우
				showErrorDialog("Error: No more parking space.");
				break;
			}
			else if (!DBC.outDB(sql+i)) { // 자리가 비어있을 경우
				if (showOptionDialog("입고하시겠습니까?", "CarIn")==0) {
					sql = "INSERT INTO pcar VALUES("+ i +", '"+ carNumText.getText() +"', '승용차')";
					
					DBC.ExeQry(sql);
					loadParkingData();
				}
				break;
			}
		}
	}
	
	private void methodSUVIn(String sql, JLabel carNumText) {
		for(int i=16; i<21; i++) {
			String sql2 = "select count(*) as num from pcar where pid"; 
			
			if (DBC.outNumber(sql2 + "<= 20") == 20) {
				showErrorDialog("Error: No more parking space.");
				break;
			}
			else if (DBC.outNumber(sql2 + ">=16") == 5) { // SUV 자리가 꽉 찼을 경우
				showErrorDialog("Error: No more parking space. (SUV)");
				break;
			}
			else if (!DBC.outDB(sql + i)) { // 자리가 비어있을 경우
				if (showOptionDialog("입고하시겠습니까?", "CarIn")==0) {
					sql = "INSERT INTO pcar VALUES("+ i +", '"+ carNumText.getText() +"', 'SUV')";
					
					DBC.ExeQry(sql);
					loadParkingData();
				}
				break;
			}
		}
	}
}