package termProjectParkingSys;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import java.awt.GridLayout;
import java.awt.FlowLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JSplitPane;
import javax.swing.SwingConstants;
import javax.swing.JRadioButton;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;

public class GUIMain extends JFrame {
	private DBController DBC = new DBController();
	
	private static final long serialVersionUID = 1L;
	
	private JPanel contentPane;
	private JLabel lblNewLabel;
	


	// Launch the application.
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUIMain frame = new GUIMain();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	// Create the frame.
	
	public GUIMain() {
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		lblNewLabel = new JLabel("");
		contentPane.setLayout(new GridLayout(2, 2, 0, 0));
		
		DBC.startConnection();
		
		JPanel chk_num_panel = new JPanel();
		chk_num_panel.setBackground(new Color(255, 255, 255));
		contentPane.add(chk_num_panel);
		chk_num_panel.setLayout(new GridLayout(3, 1, 0, 0));
		
		JPanel gong1 = new JPanel();
		gong1.setBackground(new Color(255, 255, 255));
		chk_num_panel.add(gong1);
		
		JLabel carNumber = new JLabel("");
		carNumber.setHorizontalAlignment(SwingConstants.CENTER);
		carNumber.setFont(new Font("돋움", Font.PLAIN, 30));
		chk_num_panel.add(carNumber);
		
		JPanel chk_kinds_panel = new JPanel();
		chk_kinds_panel.setBackground(new Color(255, 255, 255));
		contentPane.add(chk_kinds_panel);
		chk_kinds_panel.setLayout(new GridLayout(4, 1, 0, 0));
		
		JPanel gong2 = new JPanel();
		gong2.setBackground(new Color(255, 255, 255));
		chk_kinds_panel.add(gong2);
		
		JPanel showChkKinds = new JPanel();
		showChkKinds.setBackground(new Color(255, 255, 255));
		chk_kinds_panel.add(showChkKinds);
		
		JLabel showCom = new JLabel("차 종류 선택:");
		showCom.setFont(new Font("돋움", Font.PLAIN, 20));
		showCom.setHorizontalAlignment(SwingConstants.CENTER);
		showChkKinds.add(showCom);
		
		JPanel chkRadios = new JPanel();
		chkRadios.setBackground(new Color(255, 255, 255));
		chk_kinds_panel.add(chkRadios);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("승용차");
		rdbtnNewRadioButton_1.setBackground(new Color(255, 255, 255));
		rdbtnNewRadioButton_1.setForeground(new Color(0, 0, 0));
		rdbtnNewRadioButton_1.setFont(new Font("돋움", Font.PLAIN, 15));
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("SUV");
		rdbtnNewRadioButton.setBackground(new Color(255, 255, 255));
		rdbtnNewRadioButton.setForeground(new Color(0, 0, 0));
		rdbtnNewRadioButton.setFont(new Font("돋움", Font.PLAIN, 15));
		chkRadios.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		chkRadios.add(rdbtnNewRadioButton_1);
		chkRadios.add(rdbtnNewRadioButton);
		
		
		JPanel num_panel = new JPanel();
		num_panel.setBackground(new Color(255, 255, 255));
		contentPane.add(num_panel);
		num_panel.setLayout(new GridLayout(4, 3, 5, 5));
		
		JButton btn1 = new JButton("1");
		btn1.setFont(new Font("돋움", Font.PLAIN, 15));
		btn1.setBackground(new Color(255, 255, 255));
		num_panel.add(btn1);
		
		JButton btn2 = new JButton("2");
		btn2.setFont(new Font("돋움", Font.PLAIN, 15));
		btn2.setBackground(new Color(255, 255, 255));
		num_panel.add(btn2);
		
		JButton btn3 = new JButton("3");
		btn3.setFont(new Font("돋움", Font.PLAIN, 15));
		btn3.setBackground(new Color(255, 255, 255));
		num_panel.add(btn3);
		
		JButton btn4 = new JButton("4");
		btn4.setFont(new Font("돋움", Font.PLAIN, 15));
		btn4.setBackground(new Color(255, 255, 255));
		num_panel.add(btn4);
		
		JButton btn5 = new JButton("5");
		btn5.setFont(new Font("돋움", Font.PLAIN, 15));
		btn5.setBackground(new Color(255, 255, 255));
		num_panel.add(btn5);
		
		JButton btn6 = new JButton("6");
		btn6.setFont(new Font("돋움", Font.PLAIN, 15));
		btn6.setBackground(new Color(255, 255, 255));
		num_panel.add(btn6);
		
		JButton btn7 = new JButton("7");
		btn7.setFont(new Font("돋움", Font.PLAIN, 15));
		btn7.setBackground(new Color(255, 255, 255));
		num_panel.add(btn7);
		
		JButton btn8 = new JButton("8");
		btn8.setFont(new Font("돋움", Font.PLAIN, 15));
		btn8.setBackground(new Color(255, 255, 255));
		num_panel.add(btn8);
		
		JButton btn9 = new JButton("9");
		btn9.setFont(new Font("돋움", Font.PLAIN, 15));
		btn9.setBackground(new Color(255, 255, 255));
		num_panel.add(btn9);
		
		JButton btnDelete = new JButton("삭제");
		btnDelete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
			}
		});
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnDelete.setFont(new Font("돋움", Font.PLAIN, 15));
		btnDelete.setBackground(new Color(255, 255, 255));
		num_panel.add(btnDelete);
		
		JButton btn0 = new JButton("0");
		btn0.setFont(new Font("돋움", Font.PLAIN, 15));
		btn0.setBackground(new Color(255, 255, 255));
		num_panel.add(btn0);
		
		JButton btnADelete = new JButton("전체삭제");
		btnADelete.setVerticalAlignment(SwingConstants.BOTTOM);
		btnADelete.setFont(new Font("돋움", Font.PLAIN, 15));
		btnADelete.setBackground(new Color(255, 255, 255));
		num_panel.add(btnADelete);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(new Color(255, 255, 255));
		contentPane.add(panel_4);
		panel_4.setLayout(new GridLayout(3, 3, 0, 10));
		
		JButton btnCarIn = new JButton("입고");
		btnCarIn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int Pnum = 0;
				for(int i=0; i<20; i++) {
					if(DBC.outDB("SELECT * FROM PCAR WHERE PID="+ i) == null) {
						Pnum = 0;
						String sql = "INSERT INTO PCAR VALUES("+ i +", '자바자바', '감자바', 4000)"; // PID, CARNUM, KINDS
						DBC.ExeQry(sql);
					}
				}
				String sql = "INSERT INTO PCAR VALUES(99, '자바자바', '감자바', 4000)";
				DBC.ExeQry(sql);
			}
		});
		
		JPanel gong3 = new JPanel();
		gong3.setBackground(new Color(255, 255, 255));
		panel_4.add(gong3);
		btnCarIn.setForeground(new Color(0, 0, 0));
		btnCarIn.setBackground(new Color(255, 255, 255));
		btnCarIn.setFont(new Font("돋움", Font.PLAIN, 14));
		panel_4.add(btnCarIn);
		
		JPanel gong4 = new JPanel();
		gong4.setBackground(new Color(255, 255, 255));
		panel_4.add(gong4);
		
		JPanel gong5 = new JPanel();
		gong5.setBackground(new Color(255, 255, 255));
		panel_4.add(gong5);
		
		JButton btnCarOut = new JButton("출고");
		btnCarOut.setForeground(new Color(0, 0, 0));
		btnCarOut.setBackground(new Color(255, 255, 255));
		btnCarOut.setFont(new Font("돋움", Font.PLAIN, 14));
		panel_4.add(btnCarOut);
		
		JPanel gong6 = new JPanel();
		gong6.setBackground(new Color(255, 255, 255));
		panel_4.add(gong6);
		
		JPanel gong7 = new JPanel();
		gong7.setBackground(new Color(255, 255, 255));
		panel_4.add(gong7);
		
		JButton btnChkP = new JButton("주차장 확인");
		btnChkP.setForeground(new Color(0, 0, 0));
		btnChkP.setBackground(new Color(255, 255, 255));
		btnChkP.setFont(new Font("돋움", Font.PLAIN, 14));
		panel_4.add(btnChkP);
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
	}

}
*/