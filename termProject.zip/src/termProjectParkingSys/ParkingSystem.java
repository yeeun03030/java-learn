package termProjectParkingSys;

public class ParkingSystem {
	public void carIn() { // 입고
		
	}
	
	public void carOut() { // 출고
		
	}
	
	public void showParking() { // 주차된 차들을 보여주는
		
	}
}
