package termProjectParkingSys;

import java.io.*;
import java.sql.*;
import java.sql.CallableStatement;

public class DBController {
	Connection con;

	String url="jdbc:oracle:thin:@localhost:1521:xe";                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
	String userid="c##TP2"; /* 12버전 이상은 c##을 붙인다. */ 
	String pwd="termproject";
	
	public DBController () {
		try { /* 드라이버를 찾는 과정 */ 
			Class.forName("oracle.jdbc.driver.OracleDriver"); 
			System.out.println ("드라이버 로드 성공"); 
		} catch(ClassNotFoundException e) { 
			e.printStackTrace(); 
		}
	}
	
	public boolean startConnection() {
		boolean ret = false;
		try /* 데이터베이스를 연결하는 과정 */
		{ 
			System.out.println ("데이터베이스 연결 준비 ...");
			con=DriverManager.getConnection(url, userid, pwd);
			System.out.println ("데이터베이스 연결 성공");
			ret = true;
		} catch(SQLException e) {
			e.printStackTrace();
			ret = false;
		}
		
		return ret;
	}
	
	public void ExeQry(String sql) {
		try {
			Statement stmt = con.createStatement();
			System.out.println("들어왔어요");
			stmt.execute(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean outDB(String sql) {
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next() == true) { // 값이 있을 경우, true 반환
				System.out.println(rs.next());
				rs.close();
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return false; // null이면, false 반환
	}
	
	public int outNum() {
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM suvnum");
			
			if (rs.next()) {
				int num = rs.getInt("carnum");
				System.out.print(num);
				
				rs.close();
				return num;
			} else {
				System.out.println("No rows in the result set.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
}
