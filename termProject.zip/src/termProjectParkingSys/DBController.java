package termProjectParkingSys;

import java.io.*;
import java.sql.*;
import java.sql.CallableStatement;

public class DBController {
	Connection con;

	String url="jdbc:oracle:thin:@localhost:1521:xe";                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
	String userid="c##TP2"; /* 12버전 이상은 c##을 붙인다. */ 
	String pwd="termproject";
	
	public DBController () {
		try { /* 드라이버를 찾는 과정 */ 
			Class.forName("oracle.jdbc.driver.OracleDriver"); 
			System.out.println ("드라이버 로드 성공"); 
		} catch(ClassNotFoundException e) { 
			e.printStackTrace(); 
		}
	}
	
	public boolean startConnection() {
		boolean ret = false;
		try /* 데이터베이스를 연결하는 과정 */
		{ 
			System.out.println ("데이터베이스 연결 준비 ...");
			con=DriverManager.getConnection(url, userid, pwd);
			System.out.println ("데이터베이스 연결 성공");
			ret = true;
		} catch(SQLException e) {
			e.printStackTrace();
			ret = false;
		}
		
		return ret;
	}
	
	public void ExeQry(String sql) { // insert, delete 쓸 때
		try {
			System.out.println(sql);
			Statement stmt = con.createStatement();
			stmt.execute(sql);
			stmt.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean outDB(String sql) {
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			if(rs.next()) { // 값이 있을 경우, true 반환
				rs.close();
				stmt.close();
				return true;
			} else {
				rs.close();
				stmt.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return false; // null이면, false 반환
	}
	
	public int outNum(String str) {
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT count(*) as carnum FROM pcar WHERE pid"+ str);
			
			if (rs.next()) {
				int num = rs.getInt("carnum");
				
				rs.close();
				stmt.close();
				return num;
			} else {
				System.out.println("No rows in the result set.");
				rs.close();
				stmt.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	public int outNumber(String sql) {
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			if (rs.next()) {
				int num = rs.getInt("num");

				rs.close();
				stmt.close();
				return num;
			} else {
				System.out.println("No rows in the result set.");
				rs.close();
				stmt.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	public String showParking(int i) {
		try {
			Statement stmt = con.createStatement();
			String sql = "SELECT * FROM pcar WHERE pid="+ i;
			ResultSet rs = stmt.executeQuery(sql);
			String parksql = "";
			
			if (rs.next()) 
				parksql = rs.getString("carnum") + " (" + rs.getString("kinds") + ")";
			
			rs.close();
			stmt.close();
			return parksql;
		} catch(Exception e) {
			e.printStackTrace();
		}
		return "";
	}
}
